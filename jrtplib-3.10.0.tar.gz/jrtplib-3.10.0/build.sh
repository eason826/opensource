#!/bin/sh
#1.should be noted that building jrtp requires cmake version higher than 2.8 at least
#2.please use your actual cmake path
#3.jrtplib install path must be the same as jthread
/home/smart/cmake/bin/cmake CMakeLists.txt
make
make install
