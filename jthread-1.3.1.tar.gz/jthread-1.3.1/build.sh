#!/bin/sh
cmake CMakeLists.txt
make
make install
