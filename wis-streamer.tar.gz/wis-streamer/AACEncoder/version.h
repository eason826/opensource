#ifndef _VERSION_H_
#define _VERSION_H_

#define FAAC_RELEASE 0

#define FAAC_VERSION "1.24"

#endif
